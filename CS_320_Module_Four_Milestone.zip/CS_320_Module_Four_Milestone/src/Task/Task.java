/**
 * Nathan Vanderpool
 * CS-320
 * March 28, 2026
 */

package Task;


/**
 * Represents a Task entity in the task management system.
 * This class is immutable for the taskId field as per requirements.
 */
public class Task {
	// Task ID is final because it must not be updatable after creation
    private final String taskId;      // Unique identifier, max 10 characters
    private String name;              // Task name, max 20 characters
    private String description;       // Task description, max 50 characters

    
    /**
     * Constructs a new Task with the specified details.
     *
     * @param taskId      Unique task identifier (required, max 10 chars)
     * @param name        Name of the task (required, max 20 chars)
     * @param description Description of the task (required, max 50 chars)
     * @throws IllegalArgumentException if any parameter violates the requirements
     */
    public Task(String taskId, String name, String description) {
        // Validate taskId - required, not null, max 10 characters
        if (taskId == null || taskId.trim().isEmpty() || taskId.length() > 10) {
            throw new IllegalArgumentException("Task ID is required and cannot exceed 10 characters.");
        }

        // Validate name - required, not null, max 20 characters
        if (name == null || name.trim().isEmpty() || name.length() > 20) {
            throw new IllegalArgumentException("Name is required and cannot exceed 20 characters.");
        }

        // Validate description - required, not null, max 50 characters
        if (description == null || description.trim().isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException("Description is required and cannot exceed 50 characters.");
        }

        this.taskId = taskId.trim();
        this.name = name.trim();
        this.description = description.trim();
    }

    
    /**
     * Returns the unique task ID.
     * @return the task ID (immutable)
     */
    public String getTaskId() {
        return taskId;
    }

    
    /**
     * Returns the name of the task.
     * @return the task name
     */
    public String getName() {
        return name;
    }

    
    /**
     * Returns the description of the task.
     * @return the task description
     */
    public String getDescription() {
        return description;
    }

    
    /**
     * Updates the name of the task.
     * Only name and description are allowed to be updated per requirements.
     *
     * @param name the new name (must not be null or exceed 20 characters)
     * @throws IllegalArgumentException if name is invalid
     */
    public void setName(String name) {
        if (name == null || name.trim().isEmpty() || name.length() > 20) {
            throw new IllegalArgumentException("Name is required and cannot exceed 20 characters.");
        }
        this.name = name.trim();
    }

    
    /**
     * Updates the description of the task.
     *
     * @param description the new description (must not be null or exceed 50 characters)
     * @throws IllegalArgumentException if description is invalid
     */
    public void setDescription(String description) {
        if (description == null || description.trim().isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException("Description is required and cannot exceed 50 characters.");
        }
        this.description = description.trim();
    }
}
