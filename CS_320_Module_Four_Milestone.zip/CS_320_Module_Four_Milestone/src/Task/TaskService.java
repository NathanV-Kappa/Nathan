/**
 * Nathan Vanderpool
 * CS-320
 * March 28, 2026
 */

package Task;

import java.util.HashMap;
import java.util.Map;


/**
 * Service class responsible for managing Task objects.
 * Uses an in-memory HashMap to store tasks (no database required).
 * Supports add, delete, and update operations as specified in the requirements.
 */
public class TaskService {
	// In-memory storage for tasks using taskId as the key
    private final Map<String, Task> tasks = new HashMap<>();

    
    /**
     * Adds a new task to the service.
     * Ensures task ID is unique.
     *
     * @param task the Task object to add
     * @throws IllegalArgumentException if task is null or ID already exists
     */
    public void addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null.");
        }
        
        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("A task with ID '" + task.getTaskId() + "' already exists.");
        }
        tasks.put(task.getTaskId(), task);
    }

    
    /**
     * Deletes a task by its unique ID.
     *
     * @param taskId the ID of the task to delete
     * @throws IllegalArgumentException if taskId is null or task does not exist
     */
    public void deleteTask(String taskId) {
        if (taskId == null || !tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task with ID '" + taskId + "' does not exist.");
        }
        tasks.remove(taskId);
    }

    
    /**
     * Updates the name and/or description of an existing task.
     * Only name and description fields are updatable.
     *
     * @param taskId      the ID of the task to update
     * @param name        new name (null means no change)
     * @param description new description (null means no change)
     * @throws IllegalArgumentException if task does not exist
     */
    public void updateTask(String taskId, String name, String description) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task with ID '" + taskId + "' does not exist.");
        }

        // Update only if new values are provided
        if (name != null) {
            task.setName(name);
        }
        
        if (description != null) {
            task.setDescription(description);
        }
    }

    
    /**
     * Retrieves a task by its ID (primarily for testing purposes).
     *
     * @param taskId the ID of the task to retrieve
     * @return the Task object, or null if not found
     */
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }
}
