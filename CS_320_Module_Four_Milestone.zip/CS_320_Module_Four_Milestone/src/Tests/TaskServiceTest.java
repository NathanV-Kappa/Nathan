/**
 * Nathan Vanderpool
 * CS-320
 * March 28, 2026
 */

package Tests;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import Task.Task;
import Task.TaskService;


/**
 * Unit tests for the TaskService class.
 * Covers add, delete, and update operations with proper validation.
 */
public class TaskServiceTest {
	private TaskService taskService;

    @BeforeEach
    public void setUp() {
        taskService = new TaskService();
    }

    @Test
    public void testAddAndRetrieveTask() {
        Task task = new Task("TASK001", "Test Task", "Testing add functionality");
        taskService.addTask(task);

        Task retrieved = taskService.getTask("TASK001");
        assertNotNull(retrieved);
        assertEquals("Test Task", retrieved.getName());
    }

    @Test
    public void testAddDuplicateTaskIdThrowsException() {
        Task task1 = new Task("TASK001", "First Task", "Desc 1");
        Task task2 = new Task("TASK001", "Second Task", "Desc 2");

        taskService.addTask(task1);
        assertThrows(IllegalArgumentException.class, () -> taskService.addTask(task2));
    }

    @Test
    public void testDeleteTask() {
        Task task = new Task("TASK001", "Delete Me", "Will be removed");
        taskService.addTask(task);
        taskService.deleteTask("TASK001");

        assertNull(taskService.getTask("TASK001"));
    }

    @Test
    public void testDeleteNonExistentTaskThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> taskService.deleteTask("NONEXISTENT"));
    }

    @Test
    public void testUpdateTask() {
        Task task = new Task("TASK001", "Original Name", "Original Desc");
        taskService.addTask(task);

        taskService.updateTask("TASK001", "Updated Name", "Updated Description");

        Task updated = taskService.getTask("TASK001");
        assertEquals("Updated Name", updated.getName());
        assertEquals("Updated Description", updated.getDescription());
    }

    @Test
    public void testUpdateNonExistentTaskThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                taskService.updateTask("NONEXISTENT", "New Name", "New Desc"));
    }
}
