/**
 * Nathan Vanderpool
 * CS-320
 * March 28, 2026
 */

package Tests;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import Task.Task;


/**
 * Unit tests for the Task class.
 * Verifies all requirements for the Task object are met.
 */
public class TaskTest {
	@Test
    public void testValidTaskCreation() {
        Task task = new Task("TASK001", "Complete Project", "Finish milestone by Sunday");
        assertEquals("TASK001", task.getTaskId());
        assertEquals("Complete Project", task.getName());
        assertEquals("Finish milestone by Sunday", task.getDescription());
    }

    @Test
    public void testTaskIdTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
                new Task("VERYLONGID123", "Name", "Description"));
    }

    @Test
    public void testNameTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
                new Task("TASK001", "This name is definitely longer than twenty characters", "Desc"));
    }

    @Test
    public void testDescriptionTooLong() {
        String longDesc = "a".repeat(51);
        assertThrows(IllegalArgumentException.class, () ->
                new Task("TASK001", "Name", longDesc));
    }

    @Test
    public void testNullOrEmptyFields() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Name", "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Task("TASK001", null, "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Task("TASK001", "Name", null));
    }

    @Test
    public void testUpdateNameAndDescription() {
        Task task = new Task("TASK001", "Old Name", "Old Description");
        task.setName("Updated Name");
        task.setDescription("Updated Description");

        assertEquals("Updated Name", task.getName());
        assertEquals("Updated Description", task.getDescription());
    }
}
