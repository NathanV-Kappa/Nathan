package com.example.nathan_vanderpool_weight_tracker;

public final class Session {
    public static long userId = -1;

    private Session() {
    }
}
