package com.example.nathan_vanderpool_weight_tracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

public class HistoryActivity extends AppCompatActivity implements WeightAdapter.DeleteListener, WeightAdapter.EditListener {

    private DatabaseHelper db;
    private WeightAdapter adapter;
    private final List<WeightRow> rows = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        db = new DatabaseHelper(this);

        RecyclerView grid = findViewById(R.id.weightGrid);
        adapter = new WeightAdapter(rows, this, this);
        grid.setLayoutManager(new GridLayoutManager(this, 2));
        grid.setAdapter(adapter);

        findViewById(R.id.addWeightButton).setOnClickListener(v ->
                startActivity(new Intent(this, AddWeightActivity.class)));
        findViewById(R.id.setGoalButton).setOnClickListener(v ->
                startActivity(new Intent(this, SetGoalActivity.class)));
        findViewById(R.id.alertsButton).setOnClickListener(v ->
                startActivity(new Intent(this, SmsPermissionActivity.class)));
        findViewById(R.id.logoutButton).setOnClickListener(v -> {
            Session.userId = -1;
            Intent intent = new Intent(this, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        String goal = db.getGoal(Session.userId);
        TextView goalValue = findViewById(R.id.goalValue);
        goalValue.setText(goal.isEmpty() ? "No goal set" : getString(R.string.goal_value, goal));

        int oldSize = rows.size();
        rows.clear();
        if (oldSize > 0) {
            adapter.notifyItemRangeRemoved(0, oldSize);
        }
        rows.addAll(db.getWeights(Session.userId));
        if (!rows.isEmpty()) {
            adapter.notifyItemRangeInserted(0, rows.size());
        }
    }

    @Override
    public void onEdit(int position) {
        WeightRow row = rows.get(position);
        Intent intent = new Intent(this, AddWeightActivity.class);
        intent.putExtra(AddWeightActivity.EXTRA_WEIGHT_ID, row.id);
        intent.putExtra(AddWeightActivity.EXTRA_DATE, row.date);
        intent.putExtra(AddWeightActivity.EXTRA_WEIGHT, row.weight);
        startActivity(intent);
    }

    @Override
    public void onDelete(int position) {
        WeightRow row = rows.get(position);
        boolean removed = db.deleteWeight(row.id);
        if (!removed) {
            return;
        }
        rows.remove(position);
        adapter.notifyItemRemoved(position);
        Snackbar.make(findViewById(R.id.weightGrid), R.string.delete_confirm, Snackbar.LENGTH_LONG).show();
    }
}
