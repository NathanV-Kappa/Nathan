package com.example.nathan_vanderpool_weight_tracker;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

public class SetGoalActivity extends AppCompatActivity {

    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_goal);
        db = new DatabaseHelper(this);

        TextInputEditText goalInput = findViewById(R.id.goalInput);
        TextView goalError = findViewById(R.id.goalError);
        String current = db.getGoal(Session.userId);
        if (!current.isEmpty()) {
            goalInput.setText(current);
        }

        findViewById(R.id.saveGoalButton).setOnClickListener(v -> {
            String goal = goalInput.getText() == null ? "" : goalInput.getText().toString().trim();
            if (TextUtils.isEmpty(goal)) {
                goalError.setText(R.string.goal_error_empty);
                goalError.setVisibility(View.VISIBLE);
                return;
            }
            db.upsertGoal(Session.userId, goal);
            finish();
        });

        findViewById(R.id.cancelGoalButton).setOnClickListener(v -> finish());
    }
}
