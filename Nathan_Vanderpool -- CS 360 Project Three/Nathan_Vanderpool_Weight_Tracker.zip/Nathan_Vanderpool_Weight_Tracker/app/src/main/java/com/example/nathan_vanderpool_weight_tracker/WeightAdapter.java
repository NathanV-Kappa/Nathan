package com.example.nathan_vanderpool_weight_tracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.RowHolder> {

    public interface DeleteListener {
        void onDelete(int position);
    }

    public interface EditListener {
        void onEdit(int position);
    }

    private final List<WeightRow> rows;
    private final DeleteListener deleteListener;
    private final EditListener editListener;

    public WeightAdapter(List<WeightRow> rows, DeleteListener deleteListener, EditListener editListener) {
        this.rows = rows;
        this.deleteListener = deleteListener;
        this.editListener = editListener;
    }

    @NonNull
    @Override
    public RowHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_weight, parent, false);
        return new RowHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RowHolder holder, int position) {
        WeightRow row = rows.get(position);
        holder.date.setText(row.date);
        holder.weight.setText(row.weight);
        holder.delete.setOnClickListener(v -> deleteListener.onDelete(holder.getBindingAdapterPosition()));
        holder.edit.setOnClickListener(v -> editListener.onEdit(holder.getBindingAdapterPosition()));
    }

    @Override
    public int getItemCount() {
        return rows.size();
    }

    public static class RowHolder extends RecyclerView.ViewHolder {
        final TextView date;
        final TextView weight;
        final View delete;
        final View edit;

        RowHolder(View itemView) {
            super(itemView);
            date = itemView.findViewById(R.id.rowDate);
            weight = itemView.findViewById(R.id.rowWeight);
            delete = itemView.findViewById(R.id.rowDelete);
            edit = itemView.findViewById(R.id.rowEdit);
        }
    }
}
