package com.example.nathan_vanderpool_weight_tracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "weight_tracker.db";
    private static final int DB_VERSION = 1;

    public static final String TABLE_USERS = "users";
    public static final String TABLE_WEIGHTS = "weights";
    public static final String TABLE_GOALS = "goals";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE NOT NULL, " +
                "password TEXT NOT NULL)");

        db.execSQL("CREATE TABLE " + TABLE_WEIGHTS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "entry_date TEXT NOT NULL, " +
                "weight TEXT NOT NULL)");

        db.execSQL("CREATE TABLE " + TABLE_GOALS + " (" +
                "user_id INTEGER PRIMARY KEY, " +
                "goal_weight TEXT NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOALS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    public boolean insertUser(String username, String password) {
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);
        long id = getWritableDatabase().insert(TABLE_USERS, null, values);
        return id != -1;
    }

    public long findUserId(String username, String password) {
        Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT id FROM " + TABLE_USERS + " WHERE username = ? AND password = ?",
                new String[]{username, password});
        long id = -1;
        if (cursor.moveToFirst()) {
            id = cursor.getLong(0);
        }
        cursor.close();
        return id;
    }

    public boolean usernameExists(String username) {
        Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT id FROM " + TABLE_USERS + " WHERE username = ?",
                new String[]{username});
        boolean exists = cursor.moveToFirst();
        cursor.close();
        return exists;
    }

    public long insertWeight(long userId, String date, String weight) {
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("entry_date", date);
        values.put("weight", weight);
        long id = getWritableDatabase().insert(TABLE_WEIGHTS, null, values);
        if (id == -1) {
            throw new IllegalStateException("Weight was not saved");
        }
        return id;
    }

    public boolean updateWeight(long weightId, String date, String weight) {
        ContentValues values = new ContentValues();
        values.put("entry_date", date);
        values.put("weight", weight);
        int rows = getWritableDatabase().update(
                TABLE_WEIGHTS, values, "id = ?", new String[]{String.valueOf(weightId)});
        return rows > 0;
    }

    public boolean deleteWeight(long weightId) {
        int rows = getWritableDatabase().delete(
                TABLE_WEIGHTS, "id = ?", new String[]{String.valueOf(weightId)});
        return rows > 0;
    }

    public List<WeightRow> getWeights(long userId) {
        List<WeightRow> rows = new ArrayList<>();
        Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT id, entry_date, weight FROM " + TABLE_WEIGHTS +
                        " WHERE user_id = ? ORDER BY id DESC",
                new String[]{String.valueOf(userId)});
        while (cursor.moveToNext()) {
            rows.add(new WeightRow(cursor.getLong(0), cursor.getString(1), cursor.getString(2)));
        }
        cursor.close();
        return rows;
    }

    public String getFirstWeight(long userId) {
        Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT weight FROM " + TABLE_WEIGHTS +
                        " WHERE user_id = ? ORDER BY id ASC LIMIT 1",
                new String[]{String.valueOf(userId)});
        String weight = "";
        if (cursor.moveToFirst()) {
            weight = cursor.getString(0);
        }
        cursor.close();
        return weight;
    }

    public void upsertGoal(long userId, String goal) {
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("goal_weight", goal);
        long row = getWritableDatabase().insertWithOnConflict(
                TABLE_GOALS, null, values, SQLiteDatabase.CONFLICT_REPLACE);
        if (row == -1) {
            throw new IllegalStateException("Goal was not saved");
        }
    }

    public String getGoal(long userId) {
        Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT goal_weight FROM " + TABLE_GOALS + " WHERE user_id = ?",
                new String[]{String.valueOf(userId)});
        String goal = "";
        if (cursor.moveToFirst()) {
            goal = cursor.getString(0);
        }
        cursor.close();
        return goal;
    }
}
