package com.example.nathan_vanderpool_weight_tracker;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

public class LoginActivity extends AppCompatActivity {

    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        db = new DatabaseHelper(this);

        TextInputEditText usernameInput = findViewById(R.id.usernameInput);
        TextInputEditText passwordInput = findViewById(R.id.passwordInput);
        TextView loginError = findViewById(R.id.loginError);

        findViewById(R.id.loginButton).setOnClickListener(v -> {
            String user = textOf(usernameInput);
            String pass = textOf(passwordInput);
            if (TextUtils.isEmpty(user) || TextUtils.isEmpty(pass)) {
                showError(loginError, R.string.login_error_empty);
                return;
            }
            long id = db.findUserId(user, pass);
            if (id == -1) {
                showError(loginError, R.string.login_error_bad);
                return;
            }
            openHistory(id);
        });

        findViewById(R.id.createAccountButton).setOnClickListener(v -> {
            String user = textOf(usernameInput);
            String pass = textOf(passwordInput);
            if (TextUtils.isEmpty(user) || TextUtils.isEmpty(pass)) {
                showError(loginError, R.string.login_error_empty);
                return;
            }
            if (db.usernameExists(user)) {
                showError(loginError, R.string.login_error_taken);
                return;
            }
            if (!db.insertUser(user, pass)) {
                showError(loginError, R.string.login_error_taken);
                return;
            }
            long id = db.findUserId(user, pass);
            Toast.makeText(this, R.string.login_created, Toast.LENGTH_SHORT).show();
            openHistory(id);
        });
    }

    private String textOf(TextInputEditText field) {
        return field.getText() == null ? "" : field.getText().toString().trim();
    }

    private void showError(TextView error, int message) {
        error.setText(message);
        error.setVisibility(View.VISIBLE);
    }

    private void openHistory(long userId) {
        Session.userId = userId;
        startActivity(new Intent(this, HistoryActivity.class));
    }
}
