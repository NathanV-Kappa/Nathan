package com.example.nathan_vanderpool_weight_tracker;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.textfield.TextInputEditText;

public class SmsPermissionActivity extends AppCompatActivity {

    private static final String PREFS = "alerts";
    private static final String KEY_PHONE = "phone";

    private TextView smsStatus;
    private TextInputEditText phoneInput;

    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) {
                    savePhone();
                    smsStatus.setText(R.string.sms_status_granted);
                } else {
                    clearPhone();
                    smsStatus.setText(R.string.sms_status_denied);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        phoneInput = findViewById(R.id.phoneInput);
        smsStatus = findViewById(R.id.smsStatus);

        String savedPhone = prefs().getString(KEY_PHONE, "");
        if (!savedPhone.isEmpty()) {
            phoneInput.setText(savedPhone);
        }
        if (hasSmsPermission() && !savedPhone.isEmpty()) {
            smsStatus.setText(R.string.sms_status_granted);
        }

        findViewById(R.id.allowSmsButton).setOnClickListener(v -> {
            String phone = phoneText();
            if (TextUtils.isEmpty(phone)) {
                smsStatus.setText(R.string.sms_need_phone);
                return;
            }
            if (hasSmsPermission()) {
                savePhone();
                smsStatus.setText(R.string.sms_status_granted);
            } else {
                smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
            }
        });

        findViewById(R.id.declineSmsButton).setOnClickListener(v -> {
            clearPhone();
            smsStatus.setText(R.string.sms_status_denied);
        });
    }

    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private String phoneText() {
        return phoneInput.getText() == null ? "" : phoneInput.getText().toString().trim();
    }

    private void savePhone() {
        prefs().edit().putString(KEY_PHONE, phoneText()).apply();
    }

    private void clearPhone() {
        prefs().edit().remove(KEY_PHONE).apply();
    }

    private SharedPreferences prefs() {
        return getSharedPreferences(PREFS, MODE_PRIVATE);
    }
}
