package com.example.nathan_vanderpool_weight_tracker;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.textfield.TextInputEditText;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddWeightActivity extends AppCompatActivity {

    public static final String EXTRA_WEIGHT_ID = "weight_id";
    public static final String EXTRA_DATE = "weight_date";
    public static final String EXTRA_WEIGHT = "weight_value";

    private DatabaseHelper db;
    private long editingId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);
        db = new DatabaseHelper(this);

        TextInputEditText weightInput = findViewById(R.id.weightInput);
        TextView dateValue = findViewById(R.id.dateValue);
        TextView addError = findViewById(R.id.addError);

        editingId = getIntent().getLongExtra(EXTRA_WEIGHT_ID, -1);
        String date = getIntent().getStringExtra(EXTRA_DATE);
        String existingWeight = getIntent().getStringExtra(EXTRA_WEIGHT);
        if (date == null || date.isEmpty()) {
            date = new SimpleDateFormat("MMM d, yyyy", Locale.US).format(new Date());
        }
        dateValue.setText(date);
        if (existingWeight != null) {
            weightInput.setText(existingWeight);
        }

        String dateToSave = date;
        findViewById(R.id.saveWeightButton).setOnClickListener(v -> {
            String weight = weightInput.getText() == null ? "" : weightInput.getText().toString().trim();
            if (TextUtils.isEmpty(weight)) {
                addError.setText(R.string.add_error_empty);
                addError.setVisibility(View.VISIBLE);
                return;
            }
            if (editingId == -1) {
                long id = db.insertWeight(Session.userId, dateToSave, weight);
                if (id == -1) {
                    addError.setText(R.string.add_error_empty);
                    addError.setVisibility(View.VISIBLE);
                    return;
                }
                notifyIfGoalReached(weight);
            } else {
                boolean updated = db.updateWeight(editingId, dateToSave, weight);
                if (!updated) {
                    addError.setText(R.string.add_error_empty);
                    addError.setVisibility(View.VISIBLE);
                    return;
                }
            }
            finish();
        });

        findViewById(R.id.cancelWeightButton).setOnClickListener(v -> finish());
    }

    private void notifyIfGoalReached(String weightText) {
        String goalText = db.getGoal(Session.userId);
        if (goalText.isEmpty()) {
            return;
        }
        try {
            double weight = Double.parseDouble(weightText);
            double goal = Double.parseDouble(goalText);
            String firstText = db.getFirstWeight(Session.userId);
            if (firstText.isEmpty()) {
                return;
            }
            double first = Double.parseDouble(firstText);
            boolean reached = first > goal ? weight <= goal : weight >= goal;
            if (reached) {
                sendGoalSms(weightText, goalText);
            }
        } catch (NumberFormatException ignored) {
            // Bad number never sends a text.
        }
    }

    private void sendGoalSms(String weight, String goal) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        String phone = getSharedPreferences("alerts", MODE_PRIVATE).getString("phone", "");
        if (phone.isEmpty()) {
            return;
        }
        SmsManager smsManager = getSystemService(SmsManager.class);
        if (smsManager == null) {
            return;
        }
        String message = "Goal reached. Latest weight " + weight + " lb, goal " + goal + " lb.";
        smsManager.sendTextMessage(phone, null, message, null, null);
        Toast.makeText(this, R.string.sms_sent, Toast.LENGTH_SHORT).show();
    }
}
