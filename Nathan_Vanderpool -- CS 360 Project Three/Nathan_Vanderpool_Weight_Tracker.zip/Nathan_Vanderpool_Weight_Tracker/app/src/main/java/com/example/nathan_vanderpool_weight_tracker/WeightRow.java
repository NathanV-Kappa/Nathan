package com.example.nathan_vanderpool_weight_tracker;

public class WeightRow {
    public final long id;
    public final String date;
    public final String weight;

    public WeightRow(long id, String date, String weight) {
        this.id = id;
        this.date = date;
        this.weight = weight;
    }
}
